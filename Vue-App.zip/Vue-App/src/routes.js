import { createRouter, createWebHistory } from 'vue-router'
import Home from './components/Home.vue'
import SignUp from './components/SignUp.vue'
import Login from './components/Login.vue'
import NotFound from './components/NotFound.vue'

const routes = [
    { name: 'Home', component: Home, path: '/' },
    { name: 'SignUp', path: '/signup', component: SignUp },
    { name: 'Login', path: '/login', component: Login },
    { path: '/:catchAll(.*)', component: NotFound } // Redirect to NotFound component for unmatched routes
]

const router = createRouter({
    history: createWebHistory(),
    routes
})

export default router
