<template>
    <div class="container">
        <img src="../assets/vue.svg" alt="" srcset="">
        <h1>Login</h1>
        <div class="register">
            <input v-model="email" type="text" placeholder="Enter Your Email">
            <input v-model="password" type="password" placeholder="Enter Passowrd">
            <button v-on:click="onSubmit()" type="button">Login</button>
            <p>Do not have account? Clicke here to <router-link to="/signup">Sign Up</router-link>
            </p>
        </div>
    </div>
</template>

<script>
import axios from 'axios'
export default {
    name: 'Login',
    data(){
        return{
            email:'',
            password:''
        }
    },
    mounted() {
        let user = localStorage.getItem('user-info')
        if (user) {
            this.$router.push({ name: 'Home' })
        }
    },
    methods:{
        async onSubmit(){
            let res =await axios.get(`http://localhost:3000/users?email=${this.email}&password=${this.password}`)
            if(res.status==200 && res.data.length>0){
                localStorage.setItem("user-info", JSON.stringify(res?.data[0]))
                this.$router.push({name:'Home'})
            }else{
                // this.$router.push({name:'Login'})
            }
        }
    }
}
</script>

<style scoped>
.container{
    border: 3px solid palevioletred;
    border-radius: 5px;
    padding: 20px;
}
.register input,
.register button {
    width: 300px;
    height: 40px;
    border: 2px solid palevioletred;
    border-radius: 5px;
    margin-bottom: 20px;
    padding: 10px;
    color: palevioletred;
    display: block;
    font-size: 16px;
    box-sizing: border-box;
}

.register input::placeholder {
    color: palevioletred;}

.register button{
    background-color: palevioletred;
    font-size: 16px;
    color: white;
    cursor: pointer;
}
.register p{
    font-size: 12px;
}
</style>
