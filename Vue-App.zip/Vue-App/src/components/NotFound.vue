<template>
    <div class="not-found">
      <h1 class="title">404 - Not Found</h1>
      <p class="message">Oops! The page you are looking for does not exist.</p>
      <img src="https://media.istockphoto.com/id/1173756443/photo/3d-word-404-on-chalkboard-background-3d-rendering.jpg?s=2048x2048&w=is&k=20&c=1C40MFYgNj4o6-_S2w_kVNhnV3-38N__lX9_xyPAdlM=" alt="Not Found Image" class="not-found-image">
      <router-link to="/" class="back-link">Go back to Home</router-link>
    </div>
  </template>
  
  <script>
  export default {
    name: 'NotFound'
  }
  </script>
  
  <style scoped>
  .not-found {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  
  .title {
    font-size: 48px;
    margin-bottom: 20px;
  }
  
  .message {
    font-size: 24px;
    margin-bottom: 20px;
  }
  
  .not-found-image {
    width: 400px;
    height: auto;
    margin-top: 20px;
  }
  
  .back-link {
    margin-top: 20px;
    color: palevioletred;
    font-weight: bold;
  }
  </style>
  