<template>
    <div class="home">
        <div class="content">
            <img src="../assets/vue.svg" alt="Logo" class="logo">

            <h1>Welcome to Our Website</h1>
            <p>We're excited to have you here! Explore our amazing features and services.</p>
            <div class="features">
                <div class="feature">
                    <img src="https://plus.unsplash.com/premium_photo-1670598342794-249547599860?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Feature 1" class="feature-image">

                </div>
                <div class="feature">
                    <img src="https://plus.unsplash.com/premium_photo-1706625698049-02ddcd91361d?q=80&w=1740&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Feature 2" class="feature-image">

                </div>
                <div class="feature">
                    <img src="https://images.unsplash.com/photo-1690735340077-1706a864b919?q=80&w=1625&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Feature 3" class="feature-image">

                </div>
            </div>
        </div>
    </div>
</template>
  
<script>
export default {
    name: 'Home',
    mounted(){
        let user=localStorage.getItem('user-info')
        if(!user){
            this.$router.push({name:'SignUp'})
        }
    },
}
</script>
  
<style scoped>
.home {
    text-align: center;
}

.content {
    padding: 50px;
    color: wheat;
}

.features {
    display: flex;
    justify-content: center;
    margin-top: 50px;
}

.feature {
    width: 300px;
    margin: 0 20px;
}

.feature-image {
    width: 300px; /* Set the width to 100% */
  height: 200px; /* Let the browser calculate the height based on the aspect ratio */
}

.logo {
    width: 200px;
    height: auto;
    margin-top: 50px;
}
</style>
  